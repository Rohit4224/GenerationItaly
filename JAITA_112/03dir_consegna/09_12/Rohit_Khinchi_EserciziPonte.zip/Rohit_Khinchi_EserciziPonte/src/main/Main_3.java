package main;

import java.util.Scanner;

public class Main_3 {

	public static void main(String[] args) {
//		3- Gestisco gli ingressi a un cinema.
//		Chiedere il nome,l'età e il lavoro svolto.
//		Il prezzo base del biglietto costa 8€ a persona.
//		Scontistiche:
//			Se la persona è uno studente risparmia 2€;
//			Se la persona è over65 paga la metà;
//			Se la persona è un militare o un poliziotto risparmia 3€;
//			
//		Sovrapprezzi
//			Se la persona è un medico paga 2€ in più;
//			Se la persona ha tra i 25 e i 32 anni compresi paga 1€ in più.
//		
//		Se la persona è in un gruppo, permettere di calcolare anche il biglietto delle altre persone.
//		Se il gruppo supera le 5 persone, scontare 2€ dal prezzo totale del biglietto.
//		Stampare lo scontrino col prezzo del biglietto nominativo e la somma del prezzo dei singoli biglietti
//		(Quindi voglio vedere il nome del cliente e il prezzo del suo biglietto e alla fine il prezzo e lo sconto applicato)

		
		//D
		Scanner input;
		int numInGroup;
		String name;
		int age;
		String work;
		Double basePrice;
		boolean student;
		Double pricePersona;
		Double discount; 
		int count;
		String risposta;
		Double discountTotale;
		Double basePriceTotal;
		String rispostaGroup;
		
		//I
		input = new Scanner(System.in);
		System.out.println("Scrivi il numero di persone: ");
		numInGroup = Integer.parseInt(input.nextLine());
		basePrice = 8.0;
		count = 0;
		discount = 0.0;
		risposta = "";
		discountTotale = 0.0;
		basePriceTotal = 0.0;
		rispostaGroup = "";
		
		//C
		while (numInGroup > 0)
		{
			System.out.println((count + 1) + "° Persona: ");
			System.out.println("Scrivi il nome: ");
			name = input.nextLine();
			System.out.println("Scrivi l'età: ");
			age = Integer.parseInt(input.nextLine());
			System.out.println("Scrivi il lavoro svolto: ");
			work = input.nextLine().toLowerCase();
			System.out.println("Scrivi Y se sei studente, altimenti N");
			student = input.nextLine().equalsIgnoreCase("y");
			
			basePrice = 8.0;
			discount = 0.0;
			
//			Se la persona è uno studente risparmia 2€;
//			Se la persona è un militare o un poliziotto risparmia 3€;
			discount += (student ? 2 : 0) 
						+ (work.equalsIgnoreCase("militare") || work.equalsIgnoreCase("poliziotto")? 3 : 0);

//			Se la persona è un medico paga 2€ in più;
//			Se la persona ha tra i 25 e i 32 anni compresi paga 1€ in più.
			basePrice = (work.equalsIgnoreCase("medico") ? (basePrice += 2) : basePrice)
						+ (age >= 25 && age < 32 ? (basePrice += 1) : basePrice);
			
			pricePersona = basePrice - discount;
			
//			Se la persona è over65 paga la metà;
			if (age > 65)
			{
				pricePersona /= 2.0;
				discount += pricePersona;
			}
			count++;
			risposta += "\n--------------------------------------------------\n"
						+(count) + "° Persona: "
						+ "\nIl nome: " + Character.toUpperCase(name.charAt(0)) + name.toLowerCase().substring(1)
						+ "\nL'età: " + age
						+ "\nIl lavoro svolto: " + Character.toUpperCase(work.charAt(0)) + work.substring(1)
						+ "\nStudent: " + (student ? "Si" : "No")
						+ "\nIl Prezzo prima dello sconto: " + basePrice + "€"
						+ "\nSconto: " + discount + "€"
						+ "\nIl Prezzo Finale: " + pricePersona + "€"
						+ "\n--------------------------------------------------\n";
				
			basePriceTotal += basePrice; 
			discountTotale += discount;
			numInGroup--;
		}
		
		input.close();
		
//		Se il gruppo supera le 5 persone, scontare 2€ dal prezzo totale del biglietto.
		if (count > 5)
			discountTotale += 2;
		
//		stampo per gruppo solo quando esiste piu di una persona
		if (count > 1)
		{
			rispostaGroup = "--------------------------------------------------"
							+ "\n--------------------------------------------------"
							+ "\nTotale prezzo del gruppo di " + count + ", prima dello sconto: " + 	basePriceTotal + "€"
							+ "\nSconto: " + discountTotale + "€"
							+ "\nTotale prezzo finale del gruppo: " + (basePriceTotal - discountTotale) + "€";
		}
		if (count == 0)
			risposta = "Scrivi un numero maggiore di uno.";
		
		//O
		
		System.out.println(risposta + rispostaGroup);
	}

}
