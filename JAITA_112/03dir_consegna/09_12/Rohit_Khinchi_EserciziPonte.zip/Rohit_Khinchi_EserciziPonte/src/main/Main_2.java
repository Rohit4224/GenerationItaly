package main;

public class Main_2 {

	public static void main(String[] args) {
//		2- Far inserire dei numeri all'utente finche la somma di essi non raggiunge il valore 27(quindi finchè somma < 27).
//		Stampare in console la somma dei numeri inseriti e il numero di volte che l'utente ha 
//		inserito un numero maggiore di 10.
		
		//D
		java.util.Scanner input;
		int currNum;
		int sumNum;
		int countNumGreater10;
		String risposta;
		
//		I
		System.out.println("Inserisci dei numeri finche la somma di essi non raggiunge il valore 27(quindi finchè somma < 27)");
		sumNum = 0;
		countNumGreater10 = 0;
		risposta = "";
		currNum = 0;
		
//		C
		while (sumNum < 27)
		{
			input = new java.util.Scanner(System.in);
			currNum = Integer.parseInt(input.nextLine());
			if (currNum < 27)
			{
				sumNum += currNum;
				if (currNum > 10)
					countNumGreater10++;
			}
			else
				System.out.println("Scrivi numero minore < 27.");
			
		}
		
//		O
		
		risposta = "La somma dei numeri inseriti: " + sumNum 
				+ "\nIl numero di volte che l'utente ha inserito un numero maggiore di 10: " + countNumGreater10;
		System.out.println(risposta);
	}

}
