package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

/*
		 * Scrivere un programma che calcoli un biglietto aereo
		 * 
		 * Il biglietto di base costa 50 
		 * 
		 * Chiedere all'utente i seguenti dati:
		 * - Nome e Cognome
		 * - Eta'
		 * - Numero di Bagagli, puo' essere anche 0
		 * - Destinazione (a vostra scelta)
		 * 
		 * 
		 * se l'utente ha uno o piu' bagagli dovra' pagare di piu'
		 * 20 a bagaglio.
		 * 
		 * fate in modo che a seconda della destinazione, l'utente debba pagare
		 * una certa cifra 
		 * es.
		 * New York costa 200
		 * Milano   costa 150
		 * Madrid   costa 100
		 * 
		 * vedete voi se fare una sorta di default se utente chiede una destinazione
		 * strana o non presente in catalogo
		 * 
		 * prima di dare il biglietto e il costo totale all'utente
		 * scontare il prezzo del biglietto se utente:
		 * - minorenne (50%)
		 * - over 70   (25%)
		 * 
		 * Stampare un simil biglietto 
		 * 
		 * Nominativo: 			"Nome Cognome"
		 * Anni: 	   	 		"eta"
		 * Numero Bagagli: 		"nBagagli"
		 * Destinazione:		"destinazone scelta" 
		 * Totale Biglietto:	totale (se sconto e di quanto)
		 * 
		 * 
		 * Totale Biglietto:	150 (-50%)
		 * Totale Biglietto:	150 (-25%)
		 * 
		 */
		
		//D
		int full_ticket;
		String nome_cognome;
		int age;
		int n_bagagli;
		String destinazione;
		Scanner tastiera;
		int total_cost;
		int sconto;
		
		// I
		tastiera = new Scanner(System.in);
		nome_cognome = "";
		destinazione = "";
		sconto = 0;

		System.out.println("Please write your Full name and ENTER");
		nome_cognome = tastiera.nextLine();
		System.out.println("Please write your age and ENTER");
		age = Integer.parseInt(tastiera.nextLine());
		System.out.println("Please write number of luggage/s you have and Enter");
		n_bagagli = Integer.parseInt(tastiera.nextLine());
		System.out.println("Please write the name of city where you want to go and ENTER");
		destinazione = tastiera.nextLine();
		
		tastiera.close();
		// C
		switch(destinazione.toUpperCase())
		{
			case "NEW YORK":
				total_cost = 200;
				break;
			case "MILANO":
				total_cost = 150;
				break;
			case "MADRID":
			case "ROME":
				total_cost = 100;
				break;
			default:
				total_cost = 50;
				
		}
		
		if (n_bagagli > 0)
		{
			total_cost += n_bagagli * 20;
		}
		
		if (age > 70)
		{
			sconto = 25;
			total_cost -= total_cost * sconto/100;
		}
		else if (age < 18)
		{
			sconto = 50;
			total_cost = total_cost - (total_cost * sconto/100);
		}
		
		System.out.println("Nominativo: \t \t" + nome_cognome + "\n" 
						+ "Anni: \t \t        " + age + "\n"
						+ "Numero Bagagli:   \t" + n_bagagli + "\n"
						+ "Destinazione:	 \t" + destinazione + "\n"
						+ "Totale Biglietto: \t" + total_cost + "€");
		if(sconto > 0)
		{
			System.out.println("(" + sconto + "%" + ")" + " sconto");
		}
	}

}
