package factory;

import java.util.Map;

public interface IFactory
{
	public void fillObj(Map<String,String> map);
}
